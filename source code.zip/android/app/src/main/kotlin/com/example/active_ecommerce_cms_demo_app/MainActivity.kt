package com.example.active_ecommerce_cms_demo_app

import io.flutter.embedding.android.FlutterFragmentActivity
class MainActivity : FlutterFragmentActivity()